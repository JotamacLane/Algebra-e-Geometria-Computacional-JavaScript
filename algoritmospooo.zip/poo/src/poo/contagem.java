package poo;

import java.util.Scanner;

abstract class contagem {
	
	public static void conta( int aluno ) {
			Scanner ler = new Scanner(System.in);
		 int cont; int d=0; int c=0;
		for(cont=0; cont<aluno; cont++){	
			System.out.printf("Informe a nota do estudante");
    		int b = ler.nextInt();
				if ( b>=50){
					 
					d= d+1;
				}
				else{
					
					c= c+1;
				}
		}		
		System.out.println("Quantidade de alunos aprovados s�o: "+d);	
		System.out.println("Quantidade de alunos reprovados s�o: "+c);
	}

}
