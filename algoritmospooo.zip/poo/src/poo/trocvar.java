package poo;


abstract class trocvar {
	
	public static void trocavalor( int a, int b ) {
    int aux = a;
    a = b;
    b = aux;
    	System.out.println("O primeiro numero � "+a);
    	System.out.println("O segundo numero � "+b);
	}

}