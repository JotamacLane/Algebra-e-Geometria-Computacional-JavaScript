package poo;
abstract class fibonacci{
	
	public static void fibo(int c) {
		 int a = 1; int b= 0;
	        
	        System.out.println(b);
	        System.out.println(a);
	        
	        for(int i = 0; i < c; i++){
	            a = a + b;
	            b = a - b;
	            System.out.println(a);
	        }
	    }
	    
	}