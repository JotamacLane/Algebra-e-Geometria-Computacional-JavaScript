package poo;

import java.util.Scanner;

abstract class somatoria {
	public static void soma() {
		int a=1;int c=0; int b= 0;
		Scanner ler = new Scanner(System.in);
				while(a>0){
					System.out.printf("Informe os n�meros a serem somados: ");
				    a = ler.nextInt();
				    System.out.println("");
				    if(a>0){
						
						c= a+c;
						b= b+1;
					}
				}
				System.out.println("A soma dos n�meros s�o :"+c);
				c = c/b;
				System.out.println("A m�dia �: "+c);
		
	}
}
