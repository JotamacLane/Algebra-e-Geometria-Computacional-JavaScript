package poo;
import java.util.Scanner;


public class menu {
	
		
	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		System.out.println("Menu:");
	    System.out.println("1.Trocar variaveis.");
	    System.out.println("2.Contagem de notas.");
	    System.out.println("3.Somat�rio dos n�meros.");
	    System.out.println("4.Fatoramento dos valores.");
	    System.out.println("5.Fibonacci.");
	    
	    System.out.println("6. Chama o menu. ");
	    System.out.println("0. para encerrar a opera��o. ");
	    System.out.println("");
	    System.out.printf("Informe qual opera��o deseja realizar: ");
	    int item = ler.nextInt();
	    
	  while(item !=0) {  
	    switch(item) {
	  
	    case 1:
	    	System.out.println("Trocar variaveis");
	    	
	    	System.out.printf("Informe o primeiro n�mero: ");
		    int a = ler.nextInt();
		    
		    
		    System.out.printf("Informe o segundo n�mero: ");
		    int b = ler.nextInt();
		   	  
		    trocvar.trocavalor(a, b);
		    System.out.println("");
		    System.out.printf("Informe qual opera��o deseja realizar: ");
		    item = ler.nextInt();
		    
		    
		    
		  
	    	break;
	    case 2:
	    	System.out.println("Contagem de notas");
	    	System.out.println("");
	    	System.out.printf("Quantidade de alunos que fizeram a prova: ");
		    int aluno = ler.nextInt();
	 	
		    contagem.conta(aluno); 
		    System.out.println("");
		    System.out.printf("Informe qual opera��o deseja realizar: ");
		    item = ler.nextInt();
		  
			
	    	break ;
	    case 3:
	    	System.out.println("Somat�rio dos n�meros");
	    	
			somatoria.soma();
			System.out.println("");
			System.out.printf("Informe qual opera��o deseja realizar: ");
		    item = ler.nextInt();
			
			

	    	break;
	    case 4:
	    	System.out.println("Fatoramento dos valores");
	    	
	    	System.out.printf("Informe o numero a ser fatorado");
		     a= ler.nextInt();
		    
		    fatorial.fatora(a);
		    System.out.println("");
		    System.out.printf("Informe qual opera��o deseja realizar: ");
		    item = ler.nextInt();
		   
	    	break;
	    case 5:
	    	System.out.println("Fibonacci");
	    	System.out.println("Informe quantas sequencia ");
	    	int c= ler.nextInt();
	    	fibonacci.fibo(c);
	    	System.out.println("");
	    	System.out.printf("Informe qual opera��o deseja realizar: ");
		    item = ler.nextInt();
	   	
	    case 6:
	    	System.out.println("");
	    	System.out.println("Menu:");
		    System.out.println("1.Trocar variaveis");
		    System.out.println("2.Contagem de notas");
		    System.out.println("3.Somat�rio dos n�meros");
		    System.out.println("4.Fatoramento dos valores");
		    System.out.println("5.Fibonacci");
		    
		    System.out.println("6.Voltar para o menu");
		    System.out.printf("Informe qual opera��o deseja realizar: ");
		    item = ler.nextInt();
		    break;
	   
	    }	
	    
	    
	   
	    
	    
	    }
	  System.out.println("Voc� finalizou o programa.");
	}   	
}	    
	    
	    
		//troca de variavel
		/*if(item==1) {
		System.out.printf("Informe o primeiro n�mero: ");
	    int a = ler.nextInt();
	    
	    System.out.printf("Informe o segundo n�mero: ");
	    int b = ler.nextInt();
	   	  
	    trocvar.trocavalor(a, b);
		 
	    System.out.println("Aperte 0 para voltar ao menu.");
	    item = ler.nextInt();
		if (item!=0) {
			System.out.println("Aperte 0 para voltar ao menu.");
			item = ler.nextInt();
		}
		}*/
		
		//contagem
	/*if(item==2) {
		
		System.out.printf("Quantidade de alunos que fizeram a prova.");
	    int aluno = ler.nextInt();
 	
	    contagem.conta(aluno); 
		} 
	
		//somatoria
	
	if(item==3) {
		somatoria.soma();
		
		//Fatorial
	}
	if(item==4){
		System.out.printf("Informe o numero a ser fatorado");
	    int a= ler.nextInt();
	    
	    fatorial.fatora(a);
		
	}
	
	}*/ 
	        

		


