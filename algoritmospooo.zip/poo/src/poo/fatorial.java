package poo;

;

abstract class fatorial {
	
	public static void fatora(int a) {
		int b=0;int c=0;
		
		b= a-1;
		c= a;
		while(b>0){
			
			a= a*b ;
			b= b-1;
		}
		System.out.println("O fatorial de "+c+" � igual a  "+a);
	}
}
